package com.demo.springboot;

public class College {
	
	private Long collegeId;
	private String collegeName;
	private String  address;
	
	
	public Long getCollegeId() {
		return collegeId;
	}
	public void setCollegeId(Long  i) {
		this.collegeId = i;
	}
	public String getCollegeName() {
		return collegeName;
	}
	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
	

}
