package demo123.myProjectdemo;

	enum Subjects{
		tamil,English,Maths,Science;
		}
		public class Main{
		public static void main(String[] args){
		Subjects s=Subjects.tamil;
		System.out.println(s);
		}
		}

