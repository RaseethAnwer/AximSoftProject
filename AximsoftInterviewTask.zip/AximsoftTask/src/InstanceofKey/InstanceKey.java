package InstanceofKey;

public class InstanceKey {

	public static void main(String[] args) {
		Object obj1 = "Hello, World!";
		Object obj2 = 42;
		Object obj3 = new InstanceKey();

		System.out.println(obj1 instanceof String); // true
		System.out.println(obj2 instanceof Integer); // true
		System.out.println(obj3 instanceof InstanceKey); // true
		System.out.println(obj3 instanceof String); // false
	}

}
