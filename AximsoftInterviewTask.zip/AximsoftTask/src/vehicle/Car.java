package vehicle;

public class Car{

	public interface Vehicle {
	    void start();
	    void stop();
	}

	public static class car implements Vehicle {
	    
	@Override
	public void start() {
		System.out.println("Car started.");
		
	}

	@Override
	public void stop() {
		 System.out.println("Car stopped.");
		
	}
	public static void main(String []args){
		car c = new car();
		c.start();
		c.stop();
		
	}
}

	
}
