package vehicle;

public interface vehicle {
	void start();
	void stop();

}
