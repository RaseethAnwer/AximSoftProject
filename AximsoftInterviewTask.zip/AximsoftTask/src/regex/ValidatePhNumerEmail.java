package regex;

import java.util.Scanner;
import java.util.regex.Pattern;

public class ValidatePhNumerEmail {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		String phonePattern = "\\d{10}";

		String emailPattern = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";

		System.out.print("Enter a phone number: ");
		String phoneNumber = scanner.nextLine();

		if (Pattern.matches(phonePattern, phoneNumber)) {
			System.out.println("Valid phone number!");
		} else {
			System.out.println("Invalid phone number!");
		}

		System.out.print("Enter an email address: ");
		String emailAddress = scanner.nextLine();

		if (Pattern.matches(emailPattern, emailAddress)) {
			System.out.println("Valid email address!");
		} else {
			System.out.println("Invalid email address!");
		}

		scanner.close();
	}
}
