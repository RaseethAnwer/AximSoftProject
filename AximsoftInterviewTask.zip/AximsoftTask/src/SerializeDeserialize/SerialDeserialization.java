package SerializeDeserialize;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class SerialDeserialization {
	public static void main(String[] args) throws IOException {

		Properties properties = new Properties();

		properties.setProperty("name", "Raseeth");
		properties.setProperty("age", "21");
		properties.setProperty("email", "raseeth@gmail.com");

		FileOutputStream fileOut = new FileOutputStream("example.properties");
		properties.store(fileOut, "Example Properties File");
		fileOut.close();

		FileInputStream fileIn = new FileInputStream("example.properties");
		Properties deserializedProperties = new Properties();
		deserializedProperties.load(fileIn);
		fileIn.close();

		System.out.println(deserializedProperties);
	}
}
