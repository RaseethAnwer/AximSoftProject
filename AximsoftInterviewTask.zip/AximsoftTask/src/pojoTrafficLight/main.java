package pojoTrafficLight;

public class main {

	public static void main(String[] args) {
		Traffic traffic = new Traffic(30, 60, 10);
		System.out.println("Red: " + traffic.getRed());
		System.out.println("Green: " + traffic.getGreen());
		System.out.println("Yellow: " + traffic.getYellow());
	}

}
