package pojoTrafficLight;

public class Traffic {
	private int Red;
	private int Green;
	private int Yellow;
	
	public Traffic(int red,int green,int yellow){
		this.Red = red;
		this.Green = green;
		this.Yellow = yellow;
	}
	public int getRed() {
        return Red;
    }
    public void setRed(int red) {
        this.Red = red;
    }
    public int getGreen() {
        return Green;
    }
    
    public void setGreen(int green) {
        this.Green = green;
    }
    public int getYellow() {
        return Yellow;
    }
    
    public void setYellow(int yellow) {
        this.Yellow = yellow;
    }

}

