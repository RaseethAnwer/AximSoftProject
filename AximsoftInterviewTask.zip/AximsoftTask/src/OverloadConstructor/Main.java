package OverloadConstructor;

public class Main {
	public static void main(String[] args) {

		Student student1 = new Student("Ranjith", 22, "Cinematography");
		Student student2 = new Student("Raja", 19, "Computer Science");
		Student student3 = new Student("Raseeth", 21, "Electronics Science");
		Student student4 = new Student("Anwer", 22, "political Science");

		System.out.println("Student 1: " + student1);
		System.out.println("Student 2: " + student2);
		System.out.println("Student 3: " + student3);
		System.out.println("Student 4: " + student4);
	}
}
