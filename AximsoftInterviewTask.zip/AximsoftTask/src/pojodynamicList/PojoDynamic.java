package pojodynamicList;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import pojoTrafficLight.Traffic;

public class PojoDynamic {

	public static void main(String[] args) {

		List<Traffic> trafficList = new ArrayList<>();

		Random rand = new Random();

		for (int i = 0; i < 1000; i++) {
			int red = rand.nextInt(60) + 10;
			int green = rand.nextInt(60) + 10;
			int yellow = rand.nextInt(10) + 1;

			Traffic traffic = new Traffic(red, green, yellow);
			trafficList.add(traffic);
		}

		System.out.println("Total number of objects in the list: " + trafficList.size());

		// Iterate through the list and print the values of each object
		for (Traffic traffic : trafficList) {
			System.out.println(
					"Red: " + traffic.getRed() + ", Green: " + traffic.getGreen() + ", Yellow: " + traffic.getYellow());
		}
	}
}
