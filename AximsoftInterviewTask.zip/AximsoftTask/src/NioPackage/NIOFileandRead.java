package NioPackage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class NIOFileandRead {

	public static void main(String[] args) throws Exception {
		Path filePath = Paths.get("C:/java/AximsoftTask/message.txt");
		Files.createFile(filePath);

		String text = "Hello, world!";
		Files.write(filePath, text.getBytes());

		byte[] bytes = Files.readAllBytes(filePath);
		String text1 = new String(bytes);
		System.out.println(text1);

	}

}
