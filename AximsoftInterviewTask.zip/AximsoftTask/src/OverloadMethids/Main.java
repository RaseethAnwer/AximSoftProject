package OverloadMethids;
public class Main {
    public static void main(String[] args) {
        Cars myCar = new Cars("Toyota", "Camry", 2021);
        myCar.start();
        myCar.start("Raseeth");
        myCar.start(1);
    }
}
