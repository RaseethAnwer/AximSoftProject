package OverloadMethids;
public class Cars {
    private String make;
    private String model;
    private int year;

    public Cars(String make, String model, int year) {
        this.make = make;
        this.model = model;
        this.year = year;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public int getYear() {
        return year;
    }

    public void start() {
        System.out.println("Car started");
    }

    public void start(String driverName) {
        System.out.println(driverName + " started the car");
    }

    public void start(int gear) {
        System.out.println("Car started in gear " + gear);
    }
}
