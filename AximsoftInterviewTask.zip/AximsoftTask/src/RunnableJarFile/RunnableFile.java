package RunnableJarFile;

public class RunnableFile {

	public static void main(String[] args) {
		System.out.println("Hello World");
	}

}
