package CopyList;

import java.util.ArrayList;
import java.util.List;

public class ListToAnotherList {

	public static void main(String[] args) {

		List<Integer> sourceList = new ArrayList<>();
		sourceList.add(1);
		sourceList.add(2);
		sourceList.add(3);

		List<Integer> copyList = new ArrayList<>(sourceList);

		sourceList.set(0, 10);
		sourceList.remove(2);

		System.out.println("Source List: " + sourceList);
		System.out.println("Copy List: " + copyList);

	}

}
