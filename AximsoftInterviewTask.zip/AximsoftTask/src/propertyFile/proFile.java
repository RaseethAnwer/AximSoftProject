package propertyFile;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class proFile {

	public static void main(String[] args) {
		String fileName = "example.properties";

		try (FileInputStream fis = new FileInputStream(fileName)) {
			Properties props = new Properties();
			props.load(fis);

			for (String key : props.stringPropertyNames()) {
				String value = props.getProperty(key);
				System.out.println(key + " = " + value);
			}
		} catch (IOException e) {
			e.printStackTrace();

		}

	}
}