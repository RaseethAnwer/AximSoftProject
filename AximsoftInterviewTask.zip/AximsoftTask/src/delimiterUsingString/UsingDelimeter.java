package delimiterUsingString;

public class UsingDelimeter {

	public static void main(String[] args) {
		String str = "Hello,This,Is,My,First,Program";
		String[] values = str.split(",");
		for (String value : values) {
		    System.out.println(value);
		}

	}

}
