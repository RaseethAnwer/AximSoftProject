package reflection;

import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;

public class Main {
	public static void main(String[] args) {
		try {

			Class<?> cls = Class.forName("MyClass");
			Object obj = cls.newInstance();

			Method method1 = cls.getDeclaredMethod("method1");
			method1.invoke(obj);

			Method method2 = cls.getDeclaredMethod("method2", String.class, int.class);
			int result = (int) method2.invoke(obj, "Hello", 10);
			System.out.println("Result of method2: " + result);

		} catch (ClassNotFoundException | IllegalAccessException | InstantiationException | NoSuchMethodException
				| InvocationTargetException e) {
			e.printStackTrace();
		}
	}
}
