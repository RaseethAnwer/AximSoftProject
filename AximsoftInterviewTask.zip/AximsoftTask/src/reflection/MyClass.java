package reflection;

public class MyClass {
    public void method1() {
        System.out.println("Inside method1");
    }

    public int method2(String str, int num) {
        System.out.println("Inside method2: str = " + str + ", num = " + num);
        return str.length() + num;
    }
}

