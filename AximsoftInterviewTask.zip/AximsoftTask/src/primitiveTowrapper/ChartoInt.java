package primitiveTowrapper;

public class ChartoInt {

	public static void main(String[] args) {
		//primtive
		char c = 'a'; 
		int i = (int) c;
		System.out.println(c);
		//wrapper
		Character c1 = 'a';
		Integer i1 = (int) c1.charValue();
		System.out.println(c1);


	}

}
