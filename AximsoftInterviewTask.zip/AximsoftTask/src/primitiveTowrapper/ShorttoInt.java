package primitiveTowrapper;

public class ShorttoInt {

	public static void main(String[] args) {
		//primtive
		Short s = 10;
		int i = (int) s;
		System.out.println(i);
		//wrapper
		Short s1 = 10; 
		Integer i1 = s.intValue();
		System.out.println(i1);
	}

}
     