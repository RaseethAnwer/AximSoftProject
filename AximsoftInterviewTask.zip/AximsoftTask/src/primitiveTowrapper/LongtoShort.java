package primitiveTowrapper;

public class LongtoShort {

	public static void main(String[] args) {
		//primtive
		long l = 100;
		short s = (short) l;
		System.out.println(l);
		//wrapper
		Long l1 = 100L; 
		Short s1 = l1.shortValue();
		System.out.println(l1);

	}

}
