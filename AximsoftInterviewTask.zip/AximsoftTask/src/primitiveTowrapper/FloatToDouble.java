package primitiveTowrapper;

public class FloatToDouble {

	public static void main(String[] args) {
		//primtive
		float f = 10.5f; 
		double d = (double) f;
		System.out.println(f);
		//wrapper
		Float f1 = 10.5f; 
		Double d1 = f1.doubleValue();
		System.out.println(f1);
			}
}
