package dynamicList;

import java.util.*;

public class RemoveOddNumber {

	public static void main(String[] args) {

		List<Integer> list = new ArrayList<Integer>();
		for (int i = 1; i <= 99; i++) {
			list.add(i);
		}

		Iterator<Integer> iterator = list.iterator();
		while (iterator.hasNext()) {
			int number = iterator.next();
			if (number % 2 != 0) {
				iterator.remove();
			}
		}

		System.out.println(list);

	}
}

