package Iterator;

import java.util.ArrayList;
import java.util.ListIterator;

public class IteratorList {

	public static void main(String[] args) {
		ArrayList<String> ar = new ArrayList<String>();
		ar.add("java");
		ar.add("python");
		ar.add("C++");
		ar.add(null);
		System.out.println(ar);
		ListIterator<String> listItr = ar.listIterator();
		while (listItr.hasNext()) {
			System.out.println(listItr.next());

		}
	}
}
