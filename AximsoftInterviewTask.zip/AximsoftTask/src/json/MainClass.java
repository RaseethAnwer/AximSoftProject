package json;

import java.io.File;
import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;

public class MainClass {

	public static void main(String[] args) {

		ObjectMapper objectMapper = new ObjectMapper();

		Employee employee = new Employee("Raseeth", "Anwer", "anwer@gmail.com", 25);

		try {

			objectMapper.writeValue(new File("employee.json"), employee);

			Employee deserializedEmployee = objectMapper.readValue(new File("employee.json"), Employee.class);

			System.out.println(deserializedEmployee);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
