package Exception;

public class ArrayIndexoutofBound {

	public static void main(String[] args) {
		int[] myArray = new int[5];

		try {
			int element = myArray[5];
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Error: Array index is out of bounds."+e);
		}

	}

}
