package Exception;

public class throwNullpointerExcep {

	public static void main(String[] args) {
		try {
			String s = null;
			printLength(s);
		} catch (NullPointerException e) {
			System.out.println("NullPointerException: " + e.getMessage());
		}
	}

	public static void printLength(String s) {
		System.out.println(s.length());
	}

}
