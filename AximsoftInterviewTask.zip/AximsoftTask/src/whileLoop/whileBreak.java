package whileLoop;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class whileBreak {

	public static void main(String[] args) {
		String fileName = "C:/java/AximsoftTask/whileBreakSample.txt"; 
		String quitString = "quitme";

		try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
			String line;
			while ((line = br.readLine()) != null) {
				if (line.contains(quitString)) {
					System.out.println("Found quit string in file!");
					break;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();

		}

	}
}