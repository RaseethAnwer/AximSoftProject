package directory;

import java.io.FileWriter;
import java.io.IOException;

public class DeleteFile {

	public static void main(String[] args) {
		try {
			FileWriter writer = new FileWriter("C:/java/AximsoftTask/delete.txt");
			writer.write("");
			writer.close();

			System.out.println("file content deleted ");

		} catch (IOException e) {
			System.out.println("Error deleing file contents: " + e.getMessage());
		}

	}

}
