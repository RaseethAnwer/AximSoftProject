package directory;

import java.io.File;

public class RenameTheFile {

	public static void main(String[] args) {
		File oldFile = new File("C:/java/AximsoftTask/raseeth.txt");

		File newFile = new File("C:/java/AximsoftTask/AximSoftFile.txt");

		if (oldFile.renameTo(newFile)) {
			System.out.println("File renamed successfully.");
		} else {
			System.out.println("Error renaming file.");
		}
	}

}