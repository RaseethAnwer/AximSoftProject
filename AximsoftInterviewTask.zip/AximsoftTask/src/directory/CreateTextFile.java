package directory;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CreateTextFile {

	public static void main(String[] args) {
		try {

			File file = new File("C:/java/AximsoftTask/hello.txt");

			FileWriter writer = new FileWriter(file);

			writer.write("Hello World");

			writer.close();

			System.out.println("File created successfully.");
		} catch (IOException e) {
			System.out.println("Error creating file: " + e.getMessage());
		}
	}

}
