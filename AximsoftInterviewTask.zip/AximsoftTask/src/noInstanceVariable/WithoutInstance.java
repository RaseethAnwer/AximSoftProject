package noInstanceVariable;

public class WithoutInstance {

	public static int myInt = 1234;

	public static void myMethod() {
		System.out.println("Hello, Aximsoft");
	}
}
