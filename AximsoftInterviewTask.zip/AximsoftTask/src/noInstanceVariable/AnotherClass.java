package noInstanceVariable;
import static noInstanceVariable.WithoutInstance.*;
public class AnotherClass {

	public static void main(String[] args) {
		//Variable
		System.out.println(myInt);
		//Method
		myMethod();
	}

}
