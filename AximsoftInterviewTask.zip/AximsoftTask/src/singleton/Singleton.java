package singleton;

public class Singleton {
	private static Singleton instance = null;

    // Private constructor to prevent creating new instances
    private Singleton() {
    }

    public static Singleton getInstance() {
        if (instance == null) {
            instance = new Singleton();
        }
        return instance;
    }

    public void doSome() {
        System.out.println("I am using Singleton");
    }

}


