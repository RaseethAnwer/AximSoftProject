package forLoop;

import java.util.ArrayList;
import java.util.List;

public class ForEachPOJO {

	private String name;
	private int age;

	public ForEachPOJO(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public String getname() {
		return name;
	}

	public int getage() {
		return age;
	}

	public static void main(String[] args) {
		List<ForEachPOJO> pojoList = new ArrayList<ForEachPOJO>();
		pojoList.add(new ForEachPOJO("Raseeth", 21));
		pojoList.add(new ForEachPOJO("Raja", 19));
		pojoList.add(new ForEachPOJO("Sajitha", 45));

		for (ForEachPOJO Pojo : pojoList) {
			System.out.println("Name : " + Pojo.getname()+",Age:" + Pojo.getage());

		}
	}
}
