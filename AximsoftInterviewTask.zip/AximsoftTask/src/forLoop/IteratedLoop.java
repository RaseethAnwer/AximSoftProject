package forLoop;

public class IteratedLoop {

	public static void main(String[] args) {
		for (int i = 0; i >= -99; i--) {
			System.out.println(i);
		}

	}

}
