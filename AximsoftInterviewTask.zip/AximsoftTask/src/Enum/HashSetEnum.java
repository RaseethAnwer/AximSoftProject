package Enum;

import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;

public class HashSetEnum {

	public static void main(String[] args) {
		HashSet<String> set = new HashSet<>();
		set.add("apple");
		set.add("banana");
		set.add("orange");

		Enumeration<String> enumeration = Collections.enumeration(set);
		while (enumeration.hasMoreElements()) {
			String element = enumeration.nextElement();
			System.out.println(element);
		}
	}

}