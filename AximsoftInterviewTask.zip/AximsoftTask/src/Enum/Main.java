package Enum;
public class Main {
    public static void main(String[] args) {
       
        Subject subject = Subject.MATHS;
        System.out.println("Subject chosen: " + subject);
    }
}