package Enum;

public enum Subject {
    MATHS,
    ENGLISH,
    SCIENCE,
    SOCIAL_STUDIES
}



