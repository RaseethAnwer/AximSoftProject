package ConvertstringToBoolean;

public class StringToBoolean {

	public static void main(String[] args) {
		//primitive
		String str ="false";
		boolean bol = Boolean.parseBoolean(str);
		System.out.println("boolean primitive "+bol);
		
		//wrapper
		Boolean bool = Boolean.valueOf(str);
		System.out.println("boolean wrapper "+bool);

	}

}
