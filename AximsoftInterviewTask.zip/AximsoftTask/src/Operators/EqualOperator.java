package Operators;

public class EqualOperator {

	public static void main(String[] args) {
		String str1 = "hello";
		String str2 = "hello";
		String str3 = new String("hello");

		System.out.println(str1 == str2); // true
		System.out.println(str1 == str3); // false

		String str4 = "hello";
		String str5 = "hello";
		String str6 = new String("hello");

		System.out.println(str4.equals(str5)); // true
		System.out.println(str4.equals(str6)); // true

	}
}