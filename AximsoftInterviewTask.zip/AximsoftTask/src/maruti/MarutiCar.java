package maruti;

public class MarutiCar {
	public void start() {
		System.out.println("starting car...");
	}
}
