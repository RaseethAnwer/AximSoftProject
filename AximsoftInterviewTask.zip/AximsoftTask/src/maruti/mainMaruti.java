package maruti;

public class mainMaruti {
	public static class Maruthi extends MarutiCar {

		@Override

		public void start() {

			super.start();

			System.out.println("Starting Maruthi...");

		}

		public static void main(String[] args) {

			Maruthi maruthi = new Maruthi();

			maruthi.start();
		}
	}
}
