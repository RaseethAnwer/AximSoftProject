package MarutiCar;

public class MainCar {

	public static void main(String[] args) {
		Maruti car = new Maruti("Maruti", 2022);
		car.start();
	}
}
