package MarutiCar;

public class Maruti extends Car {
    private int year;

    public Maruti(String brand, int year) {
        super(brand);
        this.year = year;
    }

    @Override
    public void start() {
        super.start();
        System.out.println("Maruti car made in " + year);
    }
}

