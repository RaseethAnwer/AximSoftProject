package SortPOJO;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import ConvertintoPOJO.Person;

public class ComparatorPOJO {

	public static void main(String[] args) {
        List<Person2> people = new ArrayList<>();
        people.add(new Person2("Raseeth", 21));
        people.add(new Person2("Raja", 19));
        people.add(new Person2("Sajitha",45));
        
        Collections.sort(people, new AgeComparator());
        
        for (Person2 person : people) {
            System.out.println(person);
        }
    }
}

