package StaticMethod;

public class StaticNonStatic {
	public static void staticMethod() {
		System.out.println("This is a static method.");
	}

	public void nonStaticMethod() {
		System.out.println("This is a non-static method.");
		staticMethod();
	}

	public static void main(String[] args) {
		StaticNonStatic Sta = new StaticNonStatic();
		Sta.nonStaticMethod();
	}

}