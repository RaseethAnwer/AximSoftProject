package Array;

public class StringToCharArray {

	public static void main(String[] args) {
		String hello = "helloWorld";
		char[] charArray = hello.toCharArray();
		System.out.println(charArray);

	}

}
