package createAFolderAndFile;

import java.io.File;
import java.io.IOException;

public class FolderandFiles {

	public static void main(String[] args) {

		File folder = new File("C:/java/AximsoftTask");
		folder.mkdir();

		try {
			File file1 = new File(folder, "file1.xls");
			file1.createNewFile();

			File file2 = new File(folder, "file2.txt");
			file2.createNewFile();

			File file3 = new File(folder, "file3.xml");
			file3.createNewFile();

			File file4 = new File(folder, "file4.pdf");
			file4.createNewFile();

			File file5 = new File(folder, "file5.zip");
			file5.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}

		File[] files = folder.listFiles();
		for (File file : files) {
			if (file.isFile() && file.getName().endsWith(".zip")) {
				System.out.println("Zip file found: " + file.getName());
			}

		}

	}
}