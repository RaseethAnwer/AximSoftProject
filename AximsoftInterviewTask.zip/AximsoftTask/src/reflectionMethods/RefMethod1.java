package reflectionMethods;

public class RefMethod1 {
	public void method1() {
		System.out.println("Hello Raseeth from method1!");
	}

	public void method2(String name) {
		System.out.println("Hello, " + name + " from method2!");
	}

}
