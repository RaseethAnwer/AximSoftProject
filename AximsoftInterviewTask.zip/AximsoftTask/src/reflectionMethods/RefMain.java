package reflectionMethods;

import java.lang.reflect.*;

public class RefMain {

	public static void main(String[] args) throws Exception{
        Class<?> cls = Class.forName("RefMain");
        Object obj = cls.newInstance();
        
        Method method1 = cls.getDeclaredMethod("method1");
        method1.invoke(obj);
        
        Method method2 = cls.getDeclaredMethod("method2", String.class);
        method2.invoke(obj, "Anwer");
	}
}
