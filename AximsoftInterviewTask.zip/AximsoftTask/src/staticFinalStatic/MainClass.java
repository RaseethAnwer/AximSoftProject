package staticFinalStatic;
import staticFinalStatic.StaticFinalStatic;
public class MainClass {

	public static void main(String[] args) {
		
		//static variable
		int value = StaticFinalStatic.staticVariable;
		System.out.println("The value of static value "+value);
	
		//final static variable
		String str = StaticFinalStatic.FINAL_STATIC_VARIABLE;
		System.out.println("The string message "+str);
	}
	
}
