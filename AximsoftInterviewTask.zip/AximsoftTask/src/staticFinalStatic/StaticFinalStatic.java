package staticFinalStatic;

public class StaticFinalStatic {
		public static int staticVariable = 123;
		public static final String FINAL_STATIC_VARIABLE = "Hi Rupa mam";
	}


	

