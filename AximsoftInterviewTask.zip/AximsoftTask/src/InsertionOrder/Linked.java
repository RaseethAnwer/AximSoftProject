package InsertionOrder;

import java.util.LinkedList;;

public class Linked {

	public static void main(String[] args) {
		LinkedList<String> list = new LinkedList<>();
		list.add("apple");
		list.add("banana");
		list.add("orange");

		for (String fruit : list) {
			System.out.println(fruit);

		}

	}
}