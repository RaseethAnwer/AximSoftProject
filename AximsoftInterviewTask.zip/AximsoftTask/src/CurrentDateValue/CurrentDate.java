package CurrentDateValue;

import java.util.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class CurrentDate {
	private static DateTimeFormatter ofPattern(String string) {
		LocalDate currentDate = LocalDate.now();
		DateTimeFormatter formatter = CurrentDate.ofPattern("dd/MM/yyyy");
		String formattedDate = currentDate.format(formatter);
		System.out.println("Current date: " + formattedDate);
		return formatter;

	}
}
