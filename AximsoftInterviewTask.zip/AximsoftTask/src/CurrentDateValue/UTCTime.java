package CurrentDateValue;

import java.time.LocalDateTime;
import java.time.ZoneOffset;

public class UTCTime {

	public static void main(String[] args) {

		LocalDateTime currentUTCTime = LocalDateTime.now(ZoneOffset.UTC);

		System.out.println("CurrentUTC time :"+currentUTCTime);
	}
}
