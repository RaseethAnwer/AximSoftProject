package CurrentDateValue;

import java.time.LocalDate;

public class Before6Months {

	public static void main(String[] args) {

		LocalDate currentDate = LocalDate.now();

		LocalDate sixMonthsBefore = currentDate.minusMonths(6);

		System.out.println("Sixth Month Before :"+sixMonthsBefore);
	}
}
