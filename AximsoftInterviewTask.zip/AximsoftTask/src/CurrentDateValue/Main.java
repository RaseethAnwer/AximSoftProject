package CurrentDateValue;
import java.time.LocalDate;

public class Main {
  public static void main(String[] args) {
    LocalDate currentDate = LocalDate.now();
    System.out.println("Current date: " + currentDate);
  }
}
