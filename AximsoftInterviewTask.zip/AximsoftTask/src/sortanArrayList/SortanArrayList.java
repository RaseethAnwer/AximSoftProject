package sortanArrayList;

import java.util.ArrayList;
import java.util.Collections;

public class SortanArrayList {

	public static void main(String[] args) {
		ArrayList<Integer>list = new ArrayList<>();
        list.add(4);
        list.add(3);
        list.add(5);
        list.add(1);

        System.out.println("Before sorting: " + list);
        Collections.sort(list);
        System.out.println("After sorting"+list);

	}

}
