package StringBoString;

public class StringBuilderToString {

	public static void main(String[] args) {
		StringBuilder myStringBuilder = new StringBuilder("Hello Aximsoft");
		String myString = myStringBuilder.toString();
		System.out.println(myString);

	}

}
