package Switchcase;

import java.util.Scanner;

public class StringSwitchCase {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter a fruit: ");
		String fruit = scanner.nextLine();

		switch (fruit) {
		case "apple":
			System.out.println("You entered an apple.");
			break;
		case "banana":
			System.out.println("You entered a banana.");
			break;
		case "orange":
			System.out.println("You entered an orange.");
			break;
		default:
			System.out.println("You entered an unknown fruit.");
		}
	}
}
