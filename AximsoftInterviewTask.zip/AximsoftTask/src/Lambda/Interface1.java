package Lambda;

public interface Interface1 {

	void doSomething();

	void doSomethingElse();

}
