package Lambda;

public class multibleInterface implements Interface1, Interface2 {
	public static void main(String[] args) {
		multibleInterface example = new multibleInterface();
		example.doSomething();
		example.doSomethingElse();
	}

	@Override
	public void doSomething() {
		// Using a lambda expression to implement a method of Interface1
		MyInterface1 myInterface1 = () -> System.out.println("Doing something");
		myInterface1.doSomething();
	}

	@Override
	public void doSomethingElse() {
		// Using a lambda expression to implement a method of Interface2
		MyInterface2 myInterface2 = (a, b) -> a + b;
		int result = myInterface2.doSomethingElse(3, 7);
		System.out.println("Result: " + result);
	}

	interface MyInterface1 {
		void doSomething();
	}

	interface MyInterface2 {
		int doSomethingElse(int a, int b);

	}
}
