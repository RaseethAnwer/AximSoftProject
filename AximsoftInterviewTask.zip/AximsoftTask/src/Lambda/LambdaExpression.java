package Lambda;

public class LambdaExpression {

	public static void main(String[] args) {
		
		MyInterface myInterface = (a, b) -> a + b;
		int result = myInterface.add(3, 5);
		System.out.println("Result: " + result);
	}

	interface MyInterface {
		int add(int a, int b);
	}
}