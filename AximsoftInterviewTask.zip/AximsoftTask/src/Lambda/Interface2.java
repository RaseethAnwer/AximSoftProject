package Lambda;

public interface Interface2 {
	void doSomethingElse();
}
