package convertArrayintoList;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArraytoList {

	public static void main(String[] args) {
		String[] array = {"apple", "banana", "orange", "grape"};
		List<String> list = Arrays.asList(array);
		String[] array1 = {"apple", "banana", "orange", "grape"};
		List<String> list1 = new ArrayList<>(Arrays.asList(array1));
		System.out.println(list);

	}

}
