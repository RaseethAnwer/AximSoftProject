package StringToPrimitive;

public class StrToPrimitive {

	public static void main(String[] args) {
		String str = "789";
		int num = Integer.parseInt(str);
		System.out.println(num); 
	}

}
