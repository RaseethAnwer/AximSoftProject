package setIntoList;

import java.util.*;

public class SetToList {

	public static void main(String[] args) {
		Set<Integer> s = new HashSet<>();
		s.add(3);
		s.add(4);
		s.add(5);
		s.add(8);
		s.add(7);
		s.add(6);

		List<Integer> L = new ArrayList<>(s);
		System.out.println(L);
	}
}
