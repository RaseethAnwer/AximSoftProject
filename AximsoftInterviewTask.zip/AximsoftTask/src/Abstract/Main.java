package Abstract;

public class Main {
	public static void main(String[] args) {
		Car myCar = new ElectricCar("Tesla", "Model S", 2022, 100);
		myCar.start();
		myCar.stop();
	}
}
