package Abstract;

public class ElectricCar extends Car {
	private int batteryLevel;

	public ElectricCar(String make, String model, int year, int batteryLevel) {
		super(make, model, year);
		this.batteryLevel = batteryLevel;
	}

	@Override
	public void start() {
		if (batteryLevel > 0) {
			System.out.println("Electric car started");
		} else {
			System.out.println("Electric car battery dead");
		}
	}
}
