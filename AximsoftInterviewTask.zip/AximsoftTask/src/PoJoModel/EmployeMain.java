package PoJoModel;

import java.lang.reflect.InvocationTargetException;

public class EmployeMain {
	public static <T> T getEmployeeDetails(Class<T> pojoType) throws InstantiationException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {

		T pojoInstance = pojoType.getDeclaredConstructor().newInstance();

		return pojoInstance;

	}

	public static void main(String[] args) throws InstantiationException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
		EmployeeDetails empDetails = getEmployeeDetails(EmployeeDetails.class);
		empDetails.setId(11);
		empDetails.setName("Anwer");
		empDetails.setDepartment("IT");
		empDetails.setSalary(50000);

		EmployeeContactDetails empContactDetails = getEmployeeDetails(EmployeeContactDetails.class);
		empContactDetails.setAddress("391 ThirumoorthiNagar, Kuniyamuthur, CBE");
		empContactDetails.setPhoneNumber("7550327210");
		empContactDetails.setEmail("raseedanar18@gmail.com");

		System.out.println(empDetails);
		System.out.println(empContactDetails);
	}

}
