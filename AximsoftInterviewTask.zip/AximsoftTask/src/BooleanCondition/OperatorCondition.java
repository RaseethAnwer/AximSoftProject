package BooleanCondition;

public class OperatorCondition {

	public static void main(String[] args) {
		int x = 5;
		int y = 10;
		if (x > 3 & y < 15) {
		    System.out.println("Both expressions are true.");
		}
		int x1 = 5;
		int y1 = 3;
		if ((x1 > 4) && (y1 > 2)) {
		    System.out.println("Both conditions are true.");
		}

	}
	
}
