package BooleanCondition;

public class LogicalOperatpr {

	public static void main(String[] args) {
		int x = 10;
		int y = 15;
		if (x > 3 | y < 15) {
			System.out.println("At least one expression is true.");
		}
		if (x > 10 || y < 8) {
			System.out.println("At least one expression is true.");
		}
	}
}